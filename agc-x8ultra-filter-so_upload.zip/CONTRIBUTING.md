# Contributing

Please include:

- exact AGC APK filename and version
- Android version and device model
- whether preview works
- whether a photo is saved
- exact `.agc` and `.so` pairing
- SHA-256 hashes for binary files
- logcat output around library load and capture failure

Do not upload APKs, proprietary libraries, private keys, or files you do not have permission to redistribute.
