# AGC 9.6 V5 / OPPO Find X8 Ultra Filter SO Research

This repository documents an attempt to build a real ARM64 filter library for BigKaka AGC 9.6 V5 on OPPO Find X8 Ultra.

## Current Baseline

`configs/Legendary_9.6_X8Ultra_v4_capture_fix_builtin_filters.agc` is the verified camera baseline:

- four camera IDs: `2, 3, 4, 5`
- all four lenses can be activated
- photos can be captured and saved
- capture settings were adjusted to avoid the original V4 no-output problem
- the configuration is the only intended AGC base for future work

## Goal

Build a genuine `arm64-v8a` native filter library whose processing logic is actually called by AGC. Target styles include Hasselblad, Leica, Zeiss and film-inspired color treatments. The `.agc` file must contain the matching library/profile keys, but the image-processing implementation must live in the native library.

## Findings

The supplied AGC 9.6 V5 APK contains Java-side filter handling symbols including:

- `initCustomLib`
- `initCustomLut`
- `CubeUtil.getLutBitMap`
- `CubeUtil.getLutPathBitmap`
- `ImageProcessing.setLutParamters(String, float)`
- `lib_custom_lib_open_key`
- `lib_lut_key`
- `lib_lut_id_key`
- `lib_lut_intensity_key`

`initCustomLib` and `initCustomLut` are Java preference methods, not a documented native SO ABI. The supplied `高解析 (1).so` is an AArch64 ELF, but does not export those methods and has not been proven compatible with AGC V5.

## Needed From Contributors

1. Identify the native custom-library ABI used by AGC 9.6 V5.
2. Provide a working matching `.so` + `.agc` pair where a selected filter visibly changes the captured image.
3. Determine input/output image format and callback lifecycle.
4. Build a minimal pass-through ARM64 library before adding color processing.
5. Add embedded color matrices or LUT processing without changing the four-camera baseline.

## Reproduction

Use the exact AGC V5 APK variant that matches the device. Import the baseline config, verify all four lenses and a normal capture first, then test any custom library separately. Keep proprietary APKs and redistributable libraries out of this repository unless their licenses permit redistribution.

## Safety

This is reverse-engineering and compatibility research. A mismatched native library can cause black preview, failed capture, crashes or corrupted output. Always keep the working configuration and library backed up.
