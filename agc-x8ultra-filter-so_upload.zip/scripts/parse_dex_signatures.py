import struct, zipfile, pathlib
apk=pathlib.Path(r'C:\Users\XGPU999\Desktop\新建文件夹\AGC9.6.19_V5.0_inspect.apk')

def uleb(b,o):
 v=0;s=0
 while True:
  x=b[o];o+=1;v|=(x&127)<<s
  if x<128:return v,o
  s+=7

def dex_info(b):
 endian='<';
 string_ids_size,string_ids_off=struct.unpack_from('<II',b,56); type_ids_size,type_ids_off=struct.unpack_from('<II',b,64); proto_size,proto_off=struct.unpack_from('<II',b,72); method_size,method_off=struct.unpack_from('<II',b,88)
 strings=[]
 for i in range(string_ids_size):
  off=struct.unpack_from('<I',b,string_ids_off+4*i)[0]; _,p=uleb(b,off); end=b.find(b'\0',p); strings.append(b[p:end].decode('utf8','replace'))
 types=[strings[struct.unpack_from('<I',b,type_ids_off+4*i)[0]] for i in range(type_ids_size)]
 protos=[]
 for i in range(proto_size):
  shorty,ret,params=struct.unpack_from('<III',b,proto_off+12*i); ps=[]
  if params:
   n=struct.unpack_from('<I',b,params)[0]
   for j in range(n): ps.append(types[struct.unpack_from('<H',b,params+4+2*j)[0]])
  protos.append((types[ret],ps))
 hits=[]
 for i in range(method_size):
  cls,proto,name=struct.unpack_from('<HHI',b,method_off+8*i); n=strings[name]
  if 'Custom' in n or 'Lut' in n or 'lut' in n: hits.append((types[cls],n,protos[proto]))
 return hits
with zipfile.ZipFile(apk) as z:
 for n in ('classes.dex','classes2.dex','classes3.dex'):
  h=dex_info(z.read(n)); print('\n'+n+' hits='+str(len(h)))
  for x in h: print(x)
